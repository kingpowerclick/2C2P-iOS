import Foundation
import PGW

class KPC2C2P { }