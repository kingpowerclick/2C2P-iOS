//
//  PGWSDK.h
//  PGWSDK
//
//  Created by yan feng liu on 5/6/18.
//  Copyright © 2018 My2c2p. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for PGWSDK.
FOUNDATION_EXPORT double PGWSDKVersionNumber;

//! Project version string for PGWSDK.
FOUNDATION_EXPORT const unsigned char PGWSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PGWSDK/PublicHeader.h>
